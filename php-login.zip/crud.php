<html>
	<head></head>
	<body>
	<form action="crud.php" method="post">
		<?php
			$conn = new mysqli("localhost:8889", "root", "root", "login");
			if($conn->connect_error)
			{
				die("Connection failed : ". $conn->connect_error);
			}
			echo "Connected successfully" . "<br/>" . "<br/>";

			$buttonread = "";
				$buttonupdate = "";
				$buttoncreate = "";
				$buttondelete = "";
				$buttonclear = "";
				$buttonexecute = "disabled";
				$buttoncancel = "disabled";
				
				if($_SERVER['REQUEST_METHOD'] === 'POST')
				{
					// read
					if($_REQUEST['knap'] == "read")
					{
						$klubid = $_REQUEST['klubid'];
						if(is_numeric($klubid) && is_integer(0 + $klubid))
						{
							$sql =  $conn->prepare("select * from klub where id = ?");
							$sql->bind_param("i", $klubid);
							$sql->execute();
							$result = $sql->get_result();
							if($result->num_rows > 0)
							{
								$row = $result->fetch_assoc();
								$klubid = $row["id"];
								$sponsor = $row["sponsor"];
								$stadium = $row["stadium"];
								$mascot = $row["mascot"];
								$fejltekst = "read ok";
								$tekstfarve = "#000000";
							}
							else
							{
								$fejltekst = "klub nummer $klubid findes ikke";
								$tekstfarve = "#ff0000";
							}
						}
						else
						{
							$fejltekst = "klubID skal være heltal";
							$tekstfarve = "#ff0000";
						}
					}
					
					// create
					if($_REQUEST['knap'] == "create")
					{
						$klubid = $_REQUEST['klubid'];
						$sponsor = $_REQUEST['sponsor'];
						$stadium = $_REQUEST['stadium'];
						$mascot = $_REQUEST['mascot'];
						if($name == "") $name = "ukendt";
						if($sponsor == "") $sponsor = "ukendt";
						if($stadium == "") $stadium = "ukendt";
						// ok hvis $klubid er en string med et tal f.eks. "123"
						if(is_numeric($klubid) && is_integer(0 + $klubid))
						{
							if(!findes($klubid, $conn))
							{
								$sql = $conn->prepare("insert into klub (id, name, sponsor, stadium, mascot ) values (?, ?, ?, ?, ?)");
								$sql->bind_param("issi", $klubid, $name, $sponsor, $stadium, $mascot);
								$sql->execute();
								$fejltekst = "create ok";
								$tekstfarve = "#000000";
							}
							else
							{
								$fejltekst = "klub nummer $klubid findes allerede";
								$tekstfarve = "#ff0000";
							}
						}
						else
						{
							$fejltekst = "klubID skal være heltal";
							$tekstfarve = "#ff0000";
						}
					}
					
					// delete
					if($_REQUEST['knap'] == "delete")
					{
						$klubid = $_REQUEST['klubid'];
						if(is_numeric($klubid) && is_integer(0 + $klubid))
						{
							if(findes($klubid, $conn))
							{
								$_SESSION["klubtildelete"] = $klubid;
								$buttonread = "disabled";
								$buttonupdate = "disabled";
								$buttoncreate = "disabled";
								$buttondelete = "disabled";
								$buttonclear = "disabled";
								$buttonexecute = "";
								$buttoncancel = "";
								$fejltekst = "Tryk 'execute' for at slette klub $klubid . Tryk 'cancel' for at annulere";
								$tekstfarve = "#ff00ff";
							}
							else
							{
								$fejltekst = "klub nummer $klubid findes ikke";
								$tekstfarve = "#ff0000";
							}
						}
						else
						{
							$fejltekst = "klubID skal være heltal";
							$tekstfarve = "#ff0000";
						}
					}
					
					// update
					if($_REQUEST['knap'] == "update")
					{
						$bilid = $_REQUEST['bilid'];
						$model = $_REQUEST['model'];
						$farve = $_REQUEST['farve'];
						$aar = $_REQUEST['aar'];
						if($model == "") $model = "ukendt";
						if($farve == "") $farve = "ukendt";
						if($aar == "") $aar = -1;
						if(is_numeric($bilid) && is_integer(0 + $bilid) && is_numeric($aar) && is_integer(0 + $aar))
						{
							if(findes($bilid, $conn))
							{
								$sql = $conn->prepare("update klub set stadium = ?, sponsor = ?, name = ? where id = ?");
								$sql->bind_param("ssii", $stadium, $sponsor, $name, $klubid);
								$sql->execute();
								$fejltekst = "update ok";
								$tekstfarve = "#000000";
							}
							else
							{
								$fejltekst = "klub nummer $klubid findes ikke";
								$tekstfarve = "#ff0000";
							}
						}
						else
						{
							$fejltekst = "klubID skal være heltal";
							$tekstfarve = "#ff0000";
						}
					}
					
					// execute
					if($_REQUEST['knap'] == "execute")
					{
						$klubid = $_SESSION["klubtildelete"]; 
						$sql = $conn->prepare("delete from klub where id = ?");
						$sql->bind_param("i", $bilid);
						$sql->execute();
						$fejltekst = "delete ok";
						$tekstfarve = "#000000";
					}
					
					// cancel
					if($_REQUEST['knap'] == "cancel")
					{
						$bilid = "";
						$model = "";
						$farve = "";
						$aar = "";
						$fejltekst = "delete cancelled";
						$tekstfarve = "#000000";
					}
					
					// clear
					if($_REQUEST['knap'] == "clear")
					{
						$bilid = "";
						$model = "";
						$farve = "";
						$aar = "";
						$fejltekst = "klub database";
						$tekstfarve = "#000000";
					}
				}
				else
				{
					// første gang siden vises
					$fejltekst = "Klub database";
					$tekstfarve = "#000000";
				}
			
            $sql = "select * from klub";
            $result = $conn->query($sql);
			
			echo '<table border="5" bordercolor="olive" cellpadding="5">';
			echo '<tr>';
			echo '<th>KlubID</th>';
			echo '<th>Navn</th>';
			echo '<th>Sponsor</th>';
			echo '<th>Stadium</th>';
			echo '<th>Mascot</th>';
			echo '<th>Billede</th>';
			echo '<th>Billede</th>';
			echo '</tr>';
			
			if($result->num_rows > 0)
			{
				while($row = $result->fetch_assoc())
				{
					echo "<tr>";
					echo "<td>" . $row["id"] . "</td>";
					echo "<td>" . $row["name"] . "</td>";
					echo "<td>" . $row["sponsor"] . "</td>";
					echo "<td>" . $row["stadium"] . "</td>";
					echo "<td>" . $row["mascot"] . "</td>";
					echo "<td>" . "<img  src='" . $row["picture"] . "' alt='Mascot'>" . "</td>";
					echo "<td>" . $row["picture"] . "</td>";
					echo "</tr>";
				}
			}
			else
			{
				echo 'Ingen mascot';
			}

			echo "</table>";
			$conn->close();

		?>
			<p>	
				KlubID : <input type="text" name="klubid" value="<?php echo isset($klubid) ? $klubid :'' ?>" style="position: absolute; left: 100px; width: 100px; height: 22px"><br/><br/>
				Navn : <input type="text" name="name" value="<?php echo isset($name) ? $name :'' ?>" style="position: absolute; left: 100px; width: 100px; height: 22px"><br/><br/>
				Sponsor : <input type="text" name="sponsor" value="<?php echo isset($sponsor) ? $sponsor :'' ?>" style="position: absolute; left: 100px; width: 100px; height: 22px"><br/><br/>
				Stadium : <input type="text" name="stadium value="<?php echo isset($stadium) ? $stadium :'' ?>" style="position: absolute; left: 100px; width: 100px; height: 22px"><br/><br/>
				Mascot : <input type="text" name="mascot value="<?php echo isset($mascot) ? $mascot :'' ?>" style="position: absolute; left: 100px; width: 100px; height: 22px"><br/><br/>
				Status : <span style="position:absolute; left: 100px; color: <?php echo $tekstfarve ?>"><?php echo $fejltekst ?></span><br/><br/>
			</p>
			
			<p>
				<input type="submit" name="knap" value="read" style="width: 80px" <?php echo $buttonread ?>>
				<input type="submit" name="knap" value="update" style="width: 80px" <?php echo $buttonupdate ?>>
				<input type="submit" name="knap" value="create" style="width: 80px" <?php echo $buttoncreate ?>>
				<input type="submit" name="knap" value="delete" style="width: 80px" <?php echo $buttondelete ?>>
				<input type="submit" name="knap" value="clear" style="width: 80px" <?php echo $buttonclear ?>>
				<input type="submit" name="knap" value="execute" style="width: 80px" <?php echo $buttonexecute ?>>
				<input type="submit" name="knap" value="cancel" style="width: 80px" <?php echo $buttoncancel ?>>
			</p>
		</form>

	</body>
</html>